
from flask import Flask, request, jsonify
from textblob import TextBlob
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

def detectar_sentimiento(texto):
    try:
        analisis = TextBlob(texto)
        polaridad = analisis.sentiment.polarity

        if polaridad > 0.3:
            return "muy alegre"
        elif polaridad > 0.05:
            return "alegre"
        elif polaridad < -0.3:
            return "muy triste"
        elif polaridad < -0.05:
            return "triste"
        else:
            return "neutro"
    except Exception as e:
        return f"Error al analizar: {str(e)}"

frases_motivadoras = {
    "muy alegre": "¡Sigue brillando! La alegría es contagiosa. ✨",
    "alegre": "Mantén esa sonrisa, estás haciendo un gran trabajo. 😄",
    "neutro": "Cada día trae nuevas oportunidades. ¡Aprovéchalas! 🌟",
    "triste": "Incluso los días grises tienen su belleza. 'La tristeza vuela con las alas del tiempo.' — Jean de La Fontaine.",
    "muy triste": "No estás solo. 'Incluso la noche más oscura terminará y el sol saldrá.' — Victor Hugo."
}

@app.route('/analizar', methods=['POST'])
def analizar():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'sentimiento': 'Error: cuerpo inválido. Esperaba JSON'}), 400

    texto = data.get('texto', '')
    if not texto.strip():
        return jsonify({'sentimiento': 'Error: el campo "texto" está vacío o no proporcionado'}), 400

    sentimiento = detectar_sentimiento(texto)
    frase = frases_motivadoras.get(sentimiento, "Sigue adelante, lo estás haciendo bien.")
    return jsonify({'sentimiento': sentimiento, 'frase': frase})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
